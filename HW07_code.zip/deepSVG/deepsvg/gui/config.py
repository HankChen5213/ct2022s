import os

ROOT_DIR = "./gui_data"
STATE_PATH = os.path.join(ROOT_DIR, "state.pkl")
TMP_PATH = os.path.join(ROOT_DIR, "tmp")
