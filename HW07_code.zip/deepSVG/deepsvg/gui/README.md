# DeepSVG Editor: a GUI for easy SVG animation

